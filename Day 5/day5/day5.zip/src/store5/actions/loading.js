export const setLoading = (payload) => {
    return {
        type : "SET_LOADER",
        payload
    }
}